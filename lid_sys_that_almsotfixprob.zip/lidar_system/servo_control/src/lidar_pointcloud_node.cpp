#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/laser_scan.hpp"
#include "sensor_msgs/msg/point_cloud2.hpp"
#include "std_msgs/msg/float32_multi_array.hpp"
#include "laser_geometry/laser_geometry.hpp"
#include "tf2_ros/buffer.h"
#include "tf2_ros/transform_listener.h"
#include "tf2/exceptions.h"
#include "tf2_sensor_msgs/tf2_sensor_msgs.h"
#include <cmath>
#include <string>

class LaserToPointCloudNode : public rclcpp::Node
{
public:
  LaserToPointCloudNode()
  : Node("lidar_pointcloud_node"),
    tf_buffer_(this->get_clock()),
    tf_listener_(tf_buffer_),
    lookup_timeout_(rclcpp::Duration::from_seconds(0.2))
  {
    target_frame_ = this->declare_parameter<std::string>("target_frame", "base_link");
    double transform_timeout_sec = this->declare_parameter<double>("transform_timeout_sec", 0.2);
    debug_enabled_ = this->declare_parameter<bool>("debug_enabled", false);
    debug_every_n_scans_ = this->declare_parameter<int>("debug_every_n_scans", 10);
    warn_scan_age_ms_ = this->declare_parameter<double>("warn_scan_age_ms", 150.0);
    warn_tf_slip_ms_ = this->declare_parameter<double>("warn_tf_slip_ms", 60.0);
    max_scan_age_ms_ = this->declare_parameter<double>("max_scan_age_ms", 250.0);
    drop_recent_servo_scans_ = this->declare_parameter<bool>("drop_recent_servo_scans", true);
    min_servo_age_ms_ = this->declare_parameter<double>("min_servo_age_ms", 180.0);
    if (debug_every_n_scans_ <= 0) {
      debug_every_n_scans_ = 10;
    }
    if (transform_timeout_sec < 0.0) {
      RCLCPP_WARN(this->get_logger(), "transform_timeout_sec < 0, defaulting to 0.2");
      transform_timeout_sec = 0.2;
    }
    lookup_timeout_ = rclcpp::Duration::from_seconds(transform_timeout_sec);

    auto sensor_qos = rclcpp::SensorDataQoS();
    laser_subscriber_ = this->create_subscription<sensor_msgs::msg::LaserScan>(
      "/scan", sensor_qos, std::bind(&LaserToPointCloudNode::scan_callback, this, std::placeholders::_1));

    servo_subscriber_ = this->create_subscription<std_msgs::msg::Float32MultiArray>(
      "/servo_angles", sensor_qos, std::bind(&LaserToPointCloudNode::servo_callback, this, std::placeholders::_1));

    pointcloud_publisher_ = this->create_publisher<sensor_msgs::msg::PointCloud2>("/lidar_points", sensor_qos);
    RCLCPP_INFO(this->get_logger(), "Transforming /scan into frame '%s'", target_frame_.c_str());
  }

private:
  void servo_callback(const std_msgs::msg::Float32MultiArray::SharedPtr msg)
  {
    if (msg->data.size() < 2) {
      return;
    }
    latest_pan_deg_ = msg->data[0];
    latest_tilt_deg_ = msg->data[1];
    last_servo_rx_time_ = this->get_clock()->now();
    have_servo_angles_ = true;
  }

  void scan_callback(const sensor_msgs::msg::LaserScan::SharedPtr scan_msg)
  {
    ++scan_count_;
    const rclcpp::Time now = this->get_clock()->now();
    const rclcpp::Time scan_stamp = scan_msg->header.stamp;
    const double scan_age_ms = (now - scan_stamp).seconds() * 1000.0;
    double servo_age_ms = -1.0;
    if (have_servo_angles_) {
      servo_age_ms = (now - last_servo_rx_time_).seconds() * 1000.0;
    }

    if (scan_age_ms > max_scan_age_ms_) {
      RCLCPP_WARN_THROTTLE(
        this->get_logger(),
        *this->get_clock(),
        1000,
        "Dropping stale scan: age=%.1fms (limit=%.1fms)",
        scan_age_ms,
        max_scan_age_ms_);
      return;
    }

    if (drop_recent_servo_scans_ && servo_age_ms >= 0.0 && servo_age_ms < min_servo_age_ms_) {
      return;
    }

    sensor_msgs::msg::PointCloud2 cloud_out;
    try {
      // Project the laser scan into a point cloud in the scan's frame.
      projector_.projectLaser(*scan_msg, cloud_out);

      // Lookup transform from scan frame to the target frame.
      auto transform = tf_buffer_.lookupTransform(
        target_frame_, scan_msg->header.frame_id, scan_msg->header.stamp,
        lookup_timeout_);
      const rclcpp::Time tf_stamp = transform.header.stamp;
      const double tf_slip_ms = (tf_stamp - scan_stamp).seconds() * 1000.0;

      sensor_msgs::msg::PointCloud2 cloud_transformed;
      tf2::doTransform(cloud_out, cloud_transformed, transform);
      cloud_transformed.header.frame_id = target_frame_;

      pointcloud_publisher_->publish(cloud_transformed);
      if (scan_age_ms > warn_scan_age_ms_ || std::abs(tf_slip_ms) > warn_tf_slip_ms_) {
        RCLCPP_WARN_THROTTLE(
          this->get_logger(),
          *this->get_clock(),
          1000,
          "Timing warning: scan_age=%.1fms tf_slip=%.1fms target=%s source=%s",
          scan_age_ms,
          tf_slip_ms,
          target_frame_.c_str(),
          scan_msg->header.frame_id.c_str());
      }

      if (debug_enabled_ && (scan_count_ % static_cast<size_t>(debug_every_n_scans_) == 0)) {
        RCLCPP_INFO(
          this->get_logger(),
          "DBG scan#%zu scan_age=%.1fms tf_slip=%.1fms pan=%.2f tilt=%.2f servo_age=%.1fms source=%s target=%s",
          scan_count_,
          scan_age_ms,
          tf_slip_ms,
          latest_pan_deg_,
          latest_tilt_deg_,
          servo_age_ms,
          scan_msg->header.frame_id.c_str(),
          target_frame_.c_str());
      }
    }
    catch (const tf2::TransformException & ex) {
      double servo_age_ms = -1.0;
      if (have_servo_angles_) {
        servo_age_ms = (now - last_servo_rx_time_).seconds() * 1000.0;
      }
      RCLCPP_ERROR(
        this->get_logger(),
        "Could not transform scan: %s (scan_age=%.1fms pan=%.2f tilt=%.2f servo_age=%.1fms source=%s target=%s)",
        ex.what(),
        scan_age_ms,
        latest_pan_deg_,
        latest_tilt_deg_,
        servo_age_ms,
        scan_msg->header.frame_id.c_str(),
        target_frame_.c_str());
    }
  }

  rclcpp::Subscription<sensor_msgs::msg::LaserScan>::SharedPtr laser_subscriber_;
  rclcpp::Subscription<std_msgs::msg::Float32MultiArray>::SharedPtr servo_subscriber_;
  rclcpp::Publisher<sensor_msgs::msg::PointCloud2>::SharedPtr pointcloud_publisher_;
  laser_geometry::LaserProjection projector_;
  tf2_ros::Buffer tf_buffer_;
  tf2_ros::TransformListener tf_listener_;
  std::string target_frame_;
  rclcpp::Duration lookup_timeout_;
  bool debug_enabled_{false};
  int debug_every_n_scans_{10};
  double warn_scan_age_ms_{150.0};
  double warn_tf_slip_ms_{60.0};
  double max_scan_age_ms_{250.0};
  bool drop_recent_servo_scans_{true};
  double min_servo_age_ms_{180.0};
  size_t scan_count_{0};
  bool have_servo_angles_{false};
  double latest_pan_deg_{0.0};
  double latest_tilt_deg_{0.0};
  rclcpp::Time last_servo_rx_time_{0, 0, RCL_ROS_TIME};
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<LaserToPointCloudNode>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
