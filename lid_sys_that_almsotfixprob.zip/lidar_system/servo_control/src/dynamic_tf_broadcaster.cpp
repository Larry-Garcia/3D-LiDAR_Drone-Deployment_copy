#include <cmath>
#include <chrono>
#include <string>
#include "geometry_msgs/msg/transform_stamped.hpp"
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float32_multi_array.hpp"
#include "tf2/LinearMath/Quaternion.h"
#include "tf2_ros/transform_broadcaster.h"

class DynamicTFBroadcaster : public rclcpp::Node
{
public:
  DynamicTFBroadcaster()
  : Node("dynamic_tf_broadcaster"), current_pan_deg_(0.0), current_tilt_deg_(0.0)
  {
    parent_frame_ = this->declare_parameter<std::string>("parent_frame", "base_link");
    child_frame_ = this->declare_parameter<std::string>("child_frame", "laser_frame");
    offset_x_ = this->declare_parameter<double>("offset_x", 0.0);
    offset_y_ = this->declare_parameter<double>("offset_y", 0.0);
    offset_z_ = this->declare_parameter<double>("offset_z", 0.0);
    double publish_rate_hz = this->declare_parameter<double>("publish_rate_hz", 30.0);
    debug_enabled_ = this->declare_parameter<bool>("debug_enabled", false);
    debug_every_n_tf_ = this->declare_parameter<int>("debug_every_n_tf", 30);
    if (debug_every_n_tf_ <= 0) {
      debug_every_n_tf_ = 30;
    }
    if (publish_rate_hz <= 0.0) {
      RCLCPP_WARN(this->get_logger(), "publish_rate_hz <= 0, defaulting to 30Hz");
      publish_rate_hz = 30.0;
    }

    tf_broadcaster_ = std::make_shared<tf2_ros::TransformBroadcaster>(this);

    subscription_ = this->create_subscription<std_msgs::msg::Float32MultiArray>(
      "/servo_angles", 10,
      std::bind(&DynamicTFBroadcaster::angle_callback, this, std::placeholders::_1));

    timer_ = this->create_wall_timer(
      std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::duration<double>(1.0 / publish_rate_hz)),
      std::bind(&DynamicTFBroadcaster::broadcast_transform, this));

    RCLCPP_INFO(
      this->get_logger(),
      "Publishing TF %s -> %s at %.1fHz",
      parent_frame_.c_str(),
      child_frame_.c_str(),
      publish_rate_hz);
  }

private:
  void angle_callback(const std_msgs::msg::Float32MultiArray::SharedPtr msg)
  {
    if (msg->data.size() < 2) {
      RCLCPP_WARN(this->get_logger(), "Received servo_angles message with insufficient data");
      return;
    }
    current_pan_deg_ = msg->data[0];
    current_tilt_deg_ = msg->data[1];
    last_servo_msg_time_ = this->get_clock()->now();
    have_servo_msg_ = true;
  }

  void broadcast_transform()
  {
    ++tf_publish_count_;
    geometry_msgs::msg::TransformStamped t;
    t.header.stamp = this->get_clock()->now();
    t.header.frame_id = parent_frame_;
    t.child_frame_id = child_frame_;
    t.transform.translation.x = offset_x_;
    t.transform.translation.y = offset_y_;
    t.transform.translation.z = offset_z_;

    const double pan_rad = current_pan_deg_ * M_PI / 180.0;
    const double tilt_rad = current_tilt_deg_ * M_PI / 180.0;

    tf2::Quaternion q;
    q.setRPY(0.0, tilt_rad, pan_rad);
    q.normalize();

    t.transform.rotation.x = q.x();
    t.transform.rotation.y = q.y();
    t.transform.rotation.z = q.z();
    t.transform.rotation.w = q.w();

    tf_broadcaster_->sendTransform(t);

    if (debug_enabled_ && (tf_publish_count_ % static_cast<size_t>(debug_every_n_tf_) == 0)) {
      double servo_msg_age_ms = -1.0;
      if (have_servo_msg_) {
        servo_msg_age_ms = (this->get_clock()->now() - last_servo_msg_time_).seconds() * 1000.0;
      }
      RCLCPP_INFO(
        this->get_logger(),
        "DBG tf#%zu %s->%s pan=%.2f tilt=%.2f servo_msg_age=%.1fms",
        tf_publish_count_,
        parent_frame_.c_str(),
        child_frame_.c_str(),
        current_pan_deg_,
        current_tilt_deg_,
        servo_msg_age_ms);
    }
  }

  std::shared_ptr<tf2_ros::TransformBroadcaster> tf_broadcaster_;
  rclcpp::Subscription<std_msgs::msg::Float32MultiArray>::SharedPtr subscription_;
  rclcpp::TimerBase::SharedPtr timer_;

  std::string parent_frame_;
  std::string child_frame_;
  double offset_x_;
  double offset_y_;
  double offset_z_;
  double current_pan_deg_;
  double current_tilt_deg_;
  bool debug_enabled_{false};
  int debug_every_n_tf_{30};
  size_t tf_publish_count_{0};
  bool have_servo_msg_{false};
  rclcpp::Time last_servo_msg_time_{0, 0, RCL_ROS_TIME};
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<DynamicTFBroadcaster>());
  rclcpp::shutdown();
  return 0;
}
