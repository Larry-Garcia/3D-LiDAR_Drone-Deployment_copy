#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float32_multi_array.hpp"
#include <algorithm>
#include <chrono>

class ScanSequenceNode : public rclcpp::Node
{
public:
  ScanSequenceNode()
  : Node("scan_sequence_node"),
    pan_angle_(0.0),
    tilt_angle_(0.0),
    pan_increment_deg_(1.5),
    pan_direction_(1),
    dwell_ticks_(3),
    dwell_counter_(0)
  {
    timer_period_ms_ = this->declare_parameter<int>("timer_period_ms", 100);
    pan_min_deg_ = this->declare_parameter<double>("pan_min_deg", -90.0);
    pan_max_deg_ = this->declare_parameter<double>("pan_max_deg", 90.0);
    pan_increment_deg_ = this->declare_parameter<double>("pan_increment_deg", 1.5);
    tilt_start_deg_ = this->declare_parameter<double>("tilt_start_deg", 0.0);
    tilt_min_deg_ = this->declare_parameter<double>("tilt_min_deg", -45.0);
    tilt_max_deg_ = this->declare_parameter<double>("tilt_max_deg", 90.0);
    tilt_increment_deg_ = this->declare_parameter<double>("tilt_increment_deg", 10.0);
    dwell_ticks_ = this->declare_parameter<int>("dwell_ticks", 3);

    if (timer_period_ms_ <= 0) {
      timer_period_ms_ = 100;
    }
    if (dwell_ticks_ <= 0) {
      dwell_ticks_ = 1;
    }
    if (pan_max_deg_ < pan_min_deg_) {
      std::swap(pan_min_deg_, pan_max_deg_);
    }

    pan_angle_ = clamp_value(0.0, pan_min_deg_, pan_max_deg_);
    tilt_angle_ = clamp_value(tilt_start_deg_, tilt_min_deg_, tilt_max_deg_);

    publisher_ = this->create_publisher<std_msgs::msg::Float32MultiArray>("/servo_angles", 10);
    timer_ = this->create_wall_timer(
      std::chrono::milliseconds(timer_period_ms_),
      std::bind(&ScanSequenceNode::timer_callback, this));

    publish_angles();

    RCLCPP_INFO(
      this->get_logger(),
      "Scan sequence: pan[%.1f, %.1f] step=%.2fdeg, tilt[%.1f, %.1f] step=%.2fdeg, dwell_ticks=%d, period=%dms",
      pan_min_deg_, pan_max_deg_, pan_increment_deg_,
      tilt_min_deg_, tilt_max_deg_, tilt_increment_deg_,
      dwell_ticks_, timer_period_ms_);
  }

private:
  static double clamp_value(double value, double min_v, double max_v)
  {
    return std::max(min_v, std::min(value, max_v));
  }

  void publish_angles()
  {
    auto msg = std_msgs::msg::Float32MultiArray();
    msg.data.push_back(static_cast<float>(pan_angle_));
    msg.data.push_back(static_cast<float>(tilt_angle_));
    publisher_->publish(msg);
  }

  void timer_callback()
  {
    // Keep the sensor still for a few scan periods to reduce motion distortion.
    dwell_counter_++;
    if (dwell_counter_ < dwell_ticks_) {
      return;
    }
    dwell_counter_ = 0;

    pan_angle_ += pan_increment_deg_ * static_cast<double>(pan_direction_);

    if (pan_angle_ >= pan_max_deg_ || pan_angle_ <= pan_min_deg_) {
      pan_direction_ *= -1;
      pan_angle_ = clamp_value(pan_angle_, pan_min_deg_, pan_max_deg_);
      tilt_angle_ += tilt_increment_deg_;
      if (tilt_angle_ > tilt_max_deg_) {
        tilt_angle_ = tilt_min_deg_;
      }
      RCLCPP_INFO(
        this->get_logger(),
        "Pan reversed at %.2f°, Tilt updated to %.2f°",
        pan_angle_,
        tilt_angle_);
    }

    publish_angles();
  }

  rclcpp::Publisher<std_msgs::msg::Float32MultiArray>::SharedPtr publisher_;
  rclcpp::TimerBase::SharedPtr timer_;
  int timer_period_ms_;
  double pan_min_deg_;
  double pan_max_deg_;
  double tilt_start_deg_;
  double tilt_min_deg_;
  double tilt_max_deg_;
  double tilt_increment_deg_;
  int dwell_ticks_;
  int dwell_counter_;
  double pan_angle_;
  double tilt_angle_;
  double pan_increment_deg_;
  int pan_direction_;
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  auto node = std::make_shared<ScanSequenceNode>();
  rclcpp::spin(node);
  rclcpp::shutdown();
  return 0;
}
