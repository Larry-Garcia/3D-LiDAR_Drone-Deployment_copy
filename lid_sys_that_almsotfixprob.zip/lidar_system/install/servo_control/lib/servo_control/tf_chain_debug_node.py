#!/usr/bin/env python3
import rclpy
from geometry_msgs.msg import PoseStamped
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from std_msgs.msg import Float32MultiArray
from tf2_ros import Buffer, TransformListener
from typing import Tuple


class TFChainDebugNode(Node):
    def __init__(self) -> None:
        super().__init__("tf_chain_debug_node")

        self.world_frame = self.declare_parameter("world_frame", "map").value
        self.base_frame = self.declare_parameter("base_frame", "base_link").value
        self.laser_frame = self.declare_parameter("laser_frame", "laser_frame").value
        self.pose_topic = self.declare_parameter("pose_topic", "/mavros/local_position/pose").value
        self.servo_topic = self.declare_parameter("servo_topic", "/servo_angles").value
        self.check_rate_hz = float(self.declare_parameter("check_rate_hz", 2.0).value)
        if self.check_rate_hz <= 0.0:
            self.check_rate_hz = 2.0
        self.warn_age_ms = float(self.declare_parameter("warn_age_ms", 250.0).value)

        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        self.pose_sub = self.create_subscription(
            PoseStamped, self.pose_topic, self.pose_cb, qos_profile_sensor_data)
        self.servo_sub = self.create_subscription(Float32MultiArray, self.servo_topic, self.servo_cb, 10)

        self.have_pose = False
        self.have_servo = False
        self.last_pose_rx_time = None
        self.last_servo_rx_time = None
        self.last_servo_pan = 0.0
        self.last_servo_tilt = 0.0

        self.timer = self.create_timer(1.0 / self.check_rate_hz, self.check_chain)
        self.get_logger().info(
            f"TF debug started world={self.world_frame} base={self.base_frame} "
            f"laser={self.laser_frame} rate={self.check_rate_hz:.1f}Hz"
        )

    def pose_cb(self, msg: PoseStamped) -> None:
        self.have_pose = True
        self.last_pose_rx_time = self.get_clock().now()
        _ = msg

    def servo_cb(self, msg: Float32MultiArray) -> None:
        if len(msg.data) < 2:
            return
        self.have_servo = True
        self.last_servo_pan = float(msg.data[0])
        self.last_servo_tilt = float(msg.data[1])
        self.last_servo_rx_time = self.get_clock().now()

    def _fmt_age(self, t_now, t_old) -> str:
        if t_old is None:
            return "n/a"
        age_ms = (t_now - t_old).nanoseconds / 1e6
        return f"{age_ms:.1f}ms"

    def _check_one(self, target: str, source: str, now) -> Tuple[bool, str]:
        try:
            tf_msg = self.tf_buffer.lookup_transform(target, source, rclpy.time.Time())
            tf_stamp = rclpy.time.Time.from_msg(tf_msg.header.stamp)
            age_ms = (now - tf_stamp).nanoseconds / 1e6
            status = f"OK age={age_ms:.1f}ms"
            if age_ms > self.warn_age_ms:
                status += " STALE"
            return True, status
        except Exception as ex:
            msg = str(ex).replace("\n", " ")
            return False, f"FAIL {msg}"

    def check_chain(self) -> None:
        now = self.get_clock().now()
        ok_wb, wb = self._check_one(self.world_frame, self.base_frame, now)
        ok_bl, bl = self._check_one(self.base_frame, self.laser_frame, now)
        ok_wl, wl = self._check_one(self.world_frame, self.laser_frame, now)

        pose_age = self._fmt_age(now, self.last_pose_rx_time)
        servo_age = self._fmt_age(now, self.last_servo_rx_time)

        msg = (
            f"TFCHK {self.world_frame}->{self.base_frame} {wb} | "
            f"{self.base_frame}->{self.laser_frame} {bl} | "
            f"{self.world_frame}->{self.laser_frame} {wl} | "
            f"pose_age={pose_age} servo_age={servo_age} "
            f"pan={self.last_servo_pan:.2f} tilt={self.last_servo_tilt:.2f}"
        )

        if ok_wb and ok_bl and ok_wl:
            self.get_logger().info(msg)
        else:
            self.get_logger().warn(msg)
            if self.have_pose and not ok_wb:
                self.get_logger().warn(
                    "MAVROS pose is arriving but world->base TF is missing. "
                    "Enable MAVROS TF publishing or use mavros_pose_tf_bridge.py."
                )


def main() -> None:
    rclpy.init()
    node = TFChainDebugNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()

