from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    world_frame = LaunchConfiguration('world_frame')
    pointcloud_target_frame = LaunchConfiguration('pointcloud_target_frame')
    enable_pose_tf_bridge = LaunchConfiguration('enable_pose_tf_bridge')
    enable_tf_chain_debug = LaunchConfiguration('enable_tf_chain_debug')
    enable_cloud_accumulator = LaunchConfiguration('enable_cloud_accumulator')
    accumulator_passthrough_mode = LaunchConfiguration('accumulator_passthrough_mode')
    octomap_cloud_topic = LaunchConfiguration('octomap_cloud_topic')

    return LaunchDescription([
        DeclareLaunchArgument(
            'world_frame',
            default_value='map',
            description='World-fixed frame used for pointcloud and octomap (e.g. odom or map).'
        ),
        DeclareLaunchArgument(
            'pointcloud_target_frame',
            default_value='base_link',
            description='Frame used by lidar_pointcloud_node output cloud.'
        ),
        DeclareLaunchArgument(
            'enable_pose_tf_bridge',
            default_value='true',
            description='If true, publish world_frame->base_link from /mavros/local_position/pose.'
        ),
        DeclareLaunchArgument(
            'enable_tf_chain_debug',
            default_value='true',
            description='If true, run TF chain debug monitor logs.'
        ),
        DeclareLaunchArgument(
            'enable_cloud_accumulator',
            default_value='true',
            description='If true, publish /lidar_points_accum as a filtered rolling cloud.'
        ),
        DeclareLaunchArgument(
            'accumulator_passthrough_mode',
            default_value='false',
            description='If true, mirror /lidar_points to /lidar_points_accum without accumulation.'
        ),
        DeclareLaunchArgument(
            'octomap_cloud_topic',
            default_value='/lidar_points_accum',
            description='Pointcloud topic consumed by octomap cloud_in remap.'
        ),

        # RPLIDAR node
        Node(
            package='rplidar_ros',
            executable='rplidar_node',
            name='rplidar',
            parameters=[
                {'serial_baudrate': 460800},
                {'frame_id': 'laser_frame'},
            ]
        ),

        # Servo control nodes
        Node(
            package='servo_control',
            executable='scan_sequence_node',
            name='scan_sequence_node',
            parameters=[
                {'timer_period_ms': 100},
                {'pan_min_deg': -90.0},
                {'pan_max_deg': 90.0},
                {'pan_increment_deg': 1.5},
                {'tilt_start_deg': 0.0},
                {'tilt_min_deg': -15.0},
                {'tilt_max_deg': 20.0},
                {'tilt_increment_deg': 5.0},
                {'dwell_ticks': 5}
            ]
        ),
        Node(
            package='servo_control',
            executable='servo_motor_node.py',
            name='servo_motor_node'
        ),
        Node(
            package='servo_control',
            executable='dynamic_tf_broadcaster',
            name='dynamic_tf_broadcaster',
            parameters=[
                {'parent_frame': 'base_link'},
                {'child_frame': 'laser_frame'},
                {'offset_x': 0.0},
                {'offset_y': 0.0},
                {'offset_z': 0.0},
                {'publish_rate_hz': 30.0},
                {'debug_enabled': True},
                {'debug_every_n_tf': 30}
            ]
        ),
        Node(
            package='servo_control',
            executable='lidar_pointcloud_node',
            name='lidar_pointcloud_node',
            parameters=[
                {'target_frame': pointcloud_target_frame},
                {'transform_timeout_sec': 0.5},
                {'debug_enabled': True},
                {'debug_every_n_scans': 10},
                {'warn_scan_age_ms': 400.0},
                {'warn_tf_slip_ms': 60.0},
                {'max_scan_age_ms': 2000.0},
                {'drop_recent_servo_scans': False},
                {'min_servo_age_ms': 0.0}
            ]
        ),
        Node(
            package='servo_control',
            executable='pointcloud_accumulator_node.py',
            name='pointcloud_accumulator_node',
            condition=IfCondition(enable_cloud_accumulator),
            parameters=[
                {'input_topic': '/lidar_points'},
                {'output_topic': '/lidar_points_accum'},
                {'servo_topic': '/servo_angles'},
                {'output_frame': ''},
                {'passthrough_mode': accumulator_passthrough_mode},
                {'publish_rate_hz': 5.0},
                {'use_servo_bins': True},
                {'require_recent_servo': False},
                {'max_servo_age_ms': 500.0},
                {'pan_min_deg': -90.0},
                {'pan_max_deg': 90.0},
                {'pan_bin_deg': 3.0},
                {'bin_timeout_sec': 4.0},
                {'min_range_m': 0.0},
                {'max_range_m': 0.0},
                {'min_z_m': -100.0},
                {'max_z_m': 100.0},
                {'voxel_leaf_size_m': 0.0},
                {'min_points_per_bin': 1},
                {'max_output_points': 120000},
                {'debug_enabled': True},
                {'debug_every_n_pubs': 5}
            ]
        ),
        Node(
            package='servo_control',
            executable='mavros_pose_tf_bridge.py',
            name='mavros_pose_tf_bridge',
            condition=IfCondition(enable_pose_tf_bridge),
            parameters=[
                {'pose_topic': '/mavros/local_position/pose'},
                {'world_frame': world_frame},
                {'base_frame': 'base_link'},
                {'publish_rate_hz': 30.0},
                {'use_pose_stamp': True},
                {'use_pose_orientation': False},
                {'use_pose_position': True},
                {'debug_enabled': True},
                {'debug_every_n': 30}
            ]
        ),
        Node(
            package='servo_control',
            executable='tf_chain_debug_node.py',
            name='tf_chain_debug_node',
            condition=IfCondition(enable_tf_chain_debug),
            parameters=[
                {'world_frame': world_frame},
                {'base_frame': 'base_link'},
                {'laser_frame': 'laser_frame'},
                {'pose_topic': '/mavros/local_position/pose'},
                {'servo_topic': '/servo_angles'},
                {'check_rate_hz': 2.0},
                {'warn_age_ms': 250.0}
            ]
        ),
        Node(
            package='octomap_server',
            executable='octomap_server_node',
            name='octomap',
            remappings=[('cloud_in', octomap_cloud_topic)],
            parameters=[
                {'queue_size': 1000},
                {'resolution': 0.1},
                {'sensor_model/max_range': 10.0},
                {'sensor_model/hit': 0.7},
                {'sensor_model/miss': 0.4},
                {'frame_id': world_frame},
                {'transform_tolerance': 0.5}
            ]
        ),
        Node(
            package='servo_control',
            executable='lidar_bbox_open3d.py',
            name='lidar_bbox_open3d'
        ),
    ])

