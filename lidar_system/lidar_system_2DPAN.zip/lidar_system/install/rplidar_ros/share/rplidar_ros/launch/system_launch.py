from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    world_frame = LaunchConfiguration('world_frame')
    pointcloud_target_frame = LaunchConfiguration('pointcloud_target_frame')
    enable_pose_tf_bridge = LaunchConfiguration('enable_pose_tf_bridge')
    enable_tf_chain_debug = LaunchConfiguration('enable_tf_chain_debug')
    enable_cloud_accumulator = LaunchConfiguration('enable_cloud_accumulator')
    accumulator_passthrough_mode = LaunchConfiguration('accumulator_passthrough_mode')
    octomap_cloud_topic = LaunchConfiguration('octomap_cloud_topic')
    enable_2d_motion_detector = LaunchConfiguration('enable_2d_motion_detector')
    enable_scan_sequence = LaunchConfiguration('enable_scan_sequence')
    enable_2d_pan_tracker = LaunchConfiguration('enable_2d_pan_tracker')
    enable_rplidar_node = LaunchConfiguration('enable_rplidar_node')
    enable_servo_motor_node = LaunchConfiguration('enable_servo_motor_node')
    enable_dynamic_tf_broadcaster = LaunchConfiguration('enable_dynamic_tf_broadcaster')
    enable_lidar_pointcloud_node = LaunchConfiguration('enable_lidar_pointcloud_node')
    enable_octomap_server = LaunchConfiguration('enable_octomap_server')
    enable_bbox_open3d = LaunchConfiguration('enable_bbox_open3d')

    return LaunchDescription([
        DeclareLaunchArgument(
            'world_frame',
            default_value='base_link',
            description='World-fixed frame used for pointcloud and octomap (e.g. odom or map).'
        ),
        DeclareLaunchArgument(
            'pointcloud_target_frame',
            default_value='base_link',
            description='Frame used by lidar_pointcloud_node output cloud.'
        ),
        DeclareLaunchArgument(
            'enable_pose_tf_bridge',
            default_value='false',
            description='If true, publish world_frame->base_link from /mavros/local_position/pose.'
        ),
        DeclareLaunchArgument(
            'enable_tf_chain_debug',
            default_value='false',
            description='If true, run TF chain debug monitor logs.'
        ),
        DeclareLaunchArgument(
            'enable_cloud_accumulator',
            default_value='false',
            description='If true, publish /lidar_points_accum as a filtered rolling cloud.'
        ),
        DeclareLaunchArgument(
            'accumulator_passthrough_mode',
            default_value='false',
            description='If true, mirror /lidar_points to /lidar_points_accum without accumulation.'
        ),
        DeclareLaunchArgument(
            'octomap_cloud_topic',
            default_value='/lidar_points_accum',
            description='Pointcloud topic consumed by octomap cloud_in remap.'
        ),
        DeclareLaunchArgument(
            'enable_2d_motion_detector',
            default_value='true',
            description='If true, run 2D moving-object detector from /scan.'
        ),
        DeclareLaunchArgument(
            'enable_scan_sequence',
            default_value='false',
            description='If true, publish sweep /servo_angles from scan_sequence_node.'
        ),
        DeclareLaunchArgument(
            'enable_2d_pan_tracker',
            default_value='true',
            description='If true, track detected 2D target and drive /servo_angles.'
        ),
        DeclareLaunchArgument(
            'enable_rplidar_node',
            default_value='true',
            description='If true, run rplidar node.'
        ),
        DeclareLaunchArgument(
            'enable_servo_motor_node',
            default_value='true',
            description='If true, run servo motor serial command node.'
        ),
        DeclareLaunchArgument(
            'enable_dynamic_tf_broadcaster',
            default_value='false',
            description='If true, run dynamic TF broadcaster.'
        ),
        DeclareLaunchArgument(
            'enable_lidar_pointcloud_node',
            default_value='false',
            description='If true, run scan-to-pointcloud node.'
        ),
        DeclareLaunchArgument(
            'enable_octomap_server',
            default_value='false',
            description='If true, run octomap server.'
        ),
        DeclareLaunchArgument(
            'enable_bbox_open3d',
            default_value='false',
            description='If true, run Open3D bbox helper node.'
        ),

        # RPLIDAR node
        Node(
            package='rplidar_ros',
            executable='rplidar_node',
            name='rplidar',
            condition=IfCondition(enable_rplidar_node),
            parameters=[
                {'serial_baudrate': 460800},
                {'frame_id': 'laser_frame'},
            ]
        ),

        # Servo control nodes
        Node(
            package='servo_control',
            executable='scan_sequence_node',
            name='scan_sequence_node',
            condition=IfCondition(enable_scan_sequence),
            parameters=[
                {'timer_period_ms': 100},
                {'pan_min_deg': -90.0},
                {'pan_max_deg': 90.0},
                {'pan_increment_deg': 10.0},
                {'tilt_start_deg': 0.0},
                {'tilt_min_deg': 0.0},
                {'tilt_max_deg': 12.0},
                {'tilt_increment_deg': 2.0},
                {'dwell_ticks': 2}
            ]
        ),
        Node(
            package='servo_control',
            executable='servo_motor_node.py',
            name='servo_motor_node',
            condition=IfCondition(enable_servo_motor_node)
        ),
        Node(
            package='servo_control',
            executable='dynamic_tf_broadcaster',
            name='dynamic_tf_broadcaster',
            condition=IfCondition(enable_dynamic_tf_broadcaster),
            parameters=[
                {'base_frame': 'base_link'},
                {'pan_frame': 'pan_link'},
                {'tilt_frame': 'tilt_link'},
                {'laser_frame': 'laser_frame'},
                {'pan_axis': 'z'},
                {'tilt_axis': 'y'},
                {'pan_sign': 1.0},
                {'tilt_sign': 1.0},
                {'pan_bias_deg': 0.0},
                {'tilt_bias_deg': 0.0},
                # Geometric offsets (meters). Tune for your Waveshare mount geometry.
                {'pan_origin_x': 0.0},
                {'pan_origin_y': 0.0},
                {'pan_origin_z': 0.0},
                {'tilt_origin_x': 0.0},
                {'tilt_origin_y': 0.0},
                {'tilt_origin_z': 0.0},
                {'laser_origin_x': 0.0},
                {'laser_origin_y': 0.0},
                {'laser_origin_z': 0.0},
                {'laser_roll_deg': 0.0},
                {'laser_pitch_deg': 0.0},
                {'laser_yaw_deg': 0.0},
                {'publish_rate_hz': 30.0},
                {'debug_enabled': True},
                {'debug_every_n_tf': 30}
            ]
        ),
        Node(
            package='servo_control',
            executable='lidar_pointcloud_node',
            name='lidar_pointcloud_node',
            condition=IfCondition(enable_lidar_pointcloud_node),
            parameters=[
                {'target_frame': pointcloud_target_frame},
                {'transform_timeout_sec': 0.5},
                {'debug_enabled': True},
                {'debug_every_n_scans': 10},
                {'warn_scan_age_ms': 400.0},
                {'warn_tf_slip_ms': 60.0},
                {'max_scan_age_ms': 1200.0},
                {'drop_recent_servo_scans': False},
                {'min_servo_age_ms': 0.0},
                {'max_servo_age_ms': 0.0},
                {'sector_filter_enabled': False},
                {'sector_min_deg': -180.0},
                {'sector_max_deg': 180.0},
                {'filter_min_range_m': 0.80},
                {'filter_max_range_m': 4.5}
            ]
        ),
        Node(
            executable='python3',
            arguments=['/root/lidar_system/install/servo_control/lib/servo_control/pointcloud_accumulator_node.py'],
            name='pointcloud_accumulator_node',
            condition=IfCondition(enable_cloud_accumulator),
            parameters=[
                {'input_topic': '/lidar_points'},
                {'output_topic': '/lidar_points_accum'},
                {'servo_topic': '/servo_angles'},
                {'output_frame': ''},
                {'passthrough_mode': accumulator_passthrough_mode},
                {'publish_rate_hz': 10.0},
                {'use_servo_bins': True},
                {'bin_by_pan': False},
                {'bin_by_tilt': True},
                {'require_recent_servo': False},
                {'max_servo_age_ms': 1200.0},
                {'pan_min_deg': -90.0},
                {'pan_max_deg': 90.0},
                {'pan_bin_deg': 10.0},
                {'tilt_min_deg': 0.0},
                {'tilt_max_deg': 12.0},
                {'tilt_bin_deg': 2.0},
                {'bin_timeout_sec': 120.0},
                {'min_range_m': 0.80},
                {'max_range_m': 4.5},
                {'min_z_m': -0.10},
                {'max_z_m': 1.8},
                {'voxel_leaf_size_m': 0.05},
                {'min_points_per_bin': 3},
                {'max_output_points': 120000},
                {'debug_enabled': True},
                {'debug_every_n_pubs': 5}
            ]
        ),
        Node(
            executable='python3',
            arguments=['/root/lidar_system/install/servo_control/lib/servo_control/object_motion_detector_2d.py'],
            name='object_motion_detector_2d',
            condition=IfCondition(enable_2d_motion_detector),
            parameters=[
                {'scan_topic': '/scan'},
                {'detect_topic': '/moving_object_detected'},
                {'actuate_topic': '/actuation_trigger'},
                {'target_angle_topic': '/moving_object_angle_deg'},
                {'target_range_topic': '/moving_object_range_m'},
                {'marker_topic': '/moving_object_marker'},
                {'publish_marker': True},
                {'marker_size_m': 0.20},
                {'sector_min_deg': -180.0},
                {'sector_max_deg': 180.0},
                {'min_range_m': 0.25},
                {'max_range_m': 8.0},
                {'delta_range_m': 0.02},
                {'min_cluster_beams': 1},
                {'min_motion_frames': 1},
                {'trigger_cooldown_sec': 0.75},
                {'track_with_nearest_fallback': False},
                {'enable_pan_tracking': enable_2d_pan_tracker},
                {'servo_topic': '/servo_angles'},
                {'tracker_publish_rate_hz': 12.0},
                {'pan_min_deg': -90.0},
                {'pan_max_deg': 90.0},
                {'pan_center_deg': 0.0},
                {'tilt_deg': 0.0},
                {'start_pan_deg': 0.0},
                {'k_p': 0.45},
                {'max_step_deg': 8.0},
                {'deadband_deg': 0.8},
                {'target_timeout_sec': 1.0},
                {'invert_angle': False},
                {'debug_enabled': True},
                {'debug_every_n': 2}
            ]
        ),
        Node(
            package='servo_control',
            executable='mavros_pose_tf_bridge.py',
            name='mavros_pose_tf_bridge',
            condition=IfCondition(enable_pose_tf_bridge),
            parameters=[
                {'pose_topic': '/mavros/local_position/pose'},
                {'world_frame': world_frame},
                {'base_frame': 'base_link'},
                {'publish_rate_hz': 30.0},
                {'use_pose_stamp': True},
                {'use_pose_orientation': False},
                {'use_pose_position': True},
                {'publish_identity_without_pose': True},
                {'debug_enabled': True},
                {'debug_every_n': 30}
            ]
        ),
        Node(
            package='servo_control',
            executable='tf_chain_debug_node.py',
            name='tf_chain_debug_node',
            condition=IfCondition(enable_tf_chain_debug),
            parameters=[
                {'world_frame': world_frame},
                {'base_frame': 'base_link'},
                {'laser_frame': 'laser_frame'},
                {'pose_topic': '/mavros/local_position/pose'},
                {'servo_topic': '/servo_angles'},
                {'check_rate_hz': 2.0},
                {'warn_age_ms': 250.0}
            ]
        ),
        Node(
            package='octomap_server',
            executable='octomap_server_node',
            name='octomap',
            condition=IfCondition(enable_octomap_server),
            remappings=[('cloud_in', octomap_cloud_topic)],
            parameters=[
                {'queue_size': 1000},
                {'resolution': 0.1},
                {'sensor_model/max_range': 10.0},
                {'sensor_model/hit': 0.7},
                {'sensor_model/miss': 0.4},
                {'frame_id': world_frame},
                {'transform_tolerance': 0.5}
            ]
        ),
        Node(
            package='servo_control',
            executable='lidar_bbox_open3d.py',
            name='lidar_bbox_open3d',
            condition=IfCondition(enable_bbox_open3d)
        ),
    ])

