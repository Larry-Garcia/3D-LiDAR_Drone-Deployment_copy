#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
import json
import serial


class ServoControlNode(Node):
    def __init__(self):
        super().__init__('servo_control_node')
        self.port = self.declare_parameter('serial_port', '/dev/ttyTHS1').value
        self.baud = int(self.declare_parameter('serial_baud', 115200).value)
        self.pan_min_deg = float(self.declare_parameter('pan_min_deg', -90.0).value)
        self.pan_max_deg = float(self.declare_parameter('pan_max_deg', 90.0).value)
        self.tilt_min_deg = float(self.declare_parameter('tilt_min_deg', -45.0).value)
        self.tilt_max_deg = float(self.declare_parameter('tilt_max_deg', 90.0).value)
        if self.pan_max_deg < self.pan_min_deg:
            self.pan_min_deg, self.pan_max_deg = self.pan_max_deg, self.pan_min_deg
        if self.tilt_max_deg < self.tilt_min_deg:
            self.tilt_min_deg, self.tilt_max_deg = self.tilt_max_deg, self.tilt_min_deg

        self.serial_conn = None
        self._open_serial()

        self.subscription = self.create_subscription(
            Float32MultiArray,
            '/servo_angles',
            self.listener_callback,
            10)

    def _open_serial(self):
        try:
            self.serial_conn = serial.Serial(self.port, self.baud, timeout=0.1)
            self.get_logger().info(f"Opened serial {self.port} @ {self.baud}")
        except Exception as ex:
            self.serial_conn = None
            self.get_logger().error(f"Failed opening serial {self.port}: {ex}")

    def send(self, cmd):
        if self.serial_conn is None:
            self._open_serial()
            if self.serial_conn is None:
                return
        msg = json.dumps(cmd)
        try:
            self.serial_conn.write((msg + "\n").encode("utf-8"))
            self.serial_conn.flush()
        except Exception as ex:
            self.get_logger().error(f"Serial write failed: {ex}")
            try:
                if self.serial_conn is not None:
                    self.serial_conn.close()
            except Exception:
                pass
            self.serial_conn = None

    def listener_callback(self, msg):
        if len(msg.data) < 2:
            return
        pan_angle, tilt_angle = msg.data
        pan_angle = max(self.pan_min_deg, min(self.pan_max_deg, float(pan_angle)))
        tilt_angle = max(self.tilt_min_deg, min(self.tilt_max_deg, float(tilt_angle)))
        self.send({"T": 133, "X": pan_angle, "Y": tilt_angle, "SPD": 0, "ACC": 0})

    def destroy_node(self):
        try:
            if self.serial_conn is not None:
                self.serial_conn.close()
        except Exception:
            pass
        super().destroy_node()

def main(args=None):
    rclpy.init(args=args)
    servo_node = ServoControlNode()
    rclpy.spin(servo_node)
    servo_node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()

