#!/usr/bin/env python3
import math
from typing import List, Optional, Tuple

import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from geometry_msgs.msg import Point
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Bool, Float32, Float32MultiArray
from visualization_msgs.msg import Marker


class ObjectMotionDetector2D(Node):
    @staticmethod
    def _as_bool(value) -> bool:
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.strip().lower() in ("1", "true", "yes", "on")
        return bool(value)

    def __init__(self) -> None:
        super().__init__("object_motion_detector_2d")

        self.scan_topic = self.declare_parameter("scan_topic", "/scan").value
        self.detect_topic = self.declare_parameter(
            "detect_topic", "/moving_object_detected").value
        self.actuate_topic = self.declare_parameter(
            "actuate_topic", "/actuation_trigger").value
        self.target_angle_topic = self.declare_parameter(
            "target_angle_topic", "/moving_object_angle_deg").value
        self.target_range_topic = self.declare_parameter(
            "target_range_topic", "/moving_object_range_m").value
        self.marker_topic = self.declare_parameter(
            "marker_topic", "/moving_object_marker").value
        self.pan_state_topic = self.declare_parameter(
            "pan_state_topic", "/tracker_pan_cmd_deg").value
        self.pan_desired_topic = self.declare_parameter(
            "pan_desired_topic", "/tracker_pan_desired_deg").value
        self.publish_marker = self._as_bool(
            self.declare_parameter("publish_marker", True).value)
        self.marker_size_m = float(
            self.declare_parameter("marker_size_m", 0.35).value)

        self.sector_min_deg = float(
            self.declare_parameter("sector_min_deg", -60.0).value)
        self.sector_max_deg = float(
            self.declare_parameter("sector_max_deg", 60.0).value)
        if self.sector_max_deg < self.sector_min_deg:
            self.sector_min_deg, self.sector_max_deg = self.sector_max_deg, self.sector_min_deg

        self.min_range_m = float(
            self.declare_parameter("min_range_m", 0.25).value)
        self.max_range_m = float(
            self.declare_parameter("max_range_m", 8.0).value)
        self.delta_range_m = float(
            self.declare_parameter("delta_range_m", 0.06).value)
        self.min_cluster_beams = int(
            self.declare_parameter("min_cluster_beams", 1).value)
        self.min_motion_frames = int(
            self.declare_parameter("min_motion_frames", 2).value)
        self.trigger_cooldown_sec = float(
            self.declare_parameter("trigger_cooldown_sec", 0.75).value)
        self.track_with_nearest_fallback = self._as_bool(
            self.declare_parameter("track_with_nearest_fallback", False).value)
        self.debug_enabled = self._as_bool(
            self.declare_parameter("debug_enabled", True).value)
        self.debug_every_n = int(
            self.declare_parameter("debug_every_n", 10).value)

        # Optional built-in pan tracking (so we only need one 2D node/process).
        self.enable_pan_tracking = self._as_bool(
            self.declare_parameter("enable_pan_tracking", False).value)
        self.servo_topic = self.declare_parameter(
            "servo_topic", "/servo_angles").value
        self.tracker_publish_rate_hz = float(
            self.declare_parameter("tracker_publish_rate_hz", 12.0).value)
        if self.tracker_publish_rate_hz <= 0.0:
            self.tracker_publish_rate_hz = 12.0
        self.pan_min_deg = float(self.declare_parameter("pan_min_deg", -90.0).value)
        self.pan_max_deg = float(self.declare_parameter("pan_max_deg", 90.0).value)
        if self.pan_max_deg < self.pan_min_deg:
            self.pan_min_deg, self.pan_max_deg = self.pan_max_deg, self.pan_min_deg
        self.pan_center_deg = float(self.declare_parameter("pan_center_deg", 0.0).value)
        self.tilt_deg = float(self.declare_parameter("tilt_deg", 0.0).value)
        self.start_pan_deg = float(self.declare_parameter("start_pan_deg", 0.0).value)
        self.k_p = float(self.declare_parameter("k_p", 0.35).value)
        self.max_step_deg = float(self.declare_parameter("max_step_deg", 6.0).value)
        self.deadband_deg = float(self.declare_parameter("deadband_deg", 1.5).value)
        self.target_timeout_sec = float(
            self.declare_parameter("target_timeout_sec", 0.6).value)
        self.track_require_detected = self._as_bool(
            self.declare_parameter("track_require_detected", True).value)
        self.max_pan_change_for_motion_deg = float(
            self.declare_parameter("max_pan_change_for_motion_deg", 0.1).value)
        self.invert_angle = self._as_bool(
            self.declare_parameter("invert_angle", False).value)

        if self.min_cluster_beams < 1:
            self.min_cluster_beams = 1
        if self.min_motion_frames < 1:
            self.min_motion_frames = 1
        if self.debug_every_n < 1:
            self.debug_every_n = 10

        self.prev_ranges: Optional[List[float]] = None
        self.prev_stamp = None
        self.motion_streak = 0
        self.last_detect_state = False
        self.last_trigger_time = self.get_clock().now()
        self.scan_count = 0
        self.pan_cmd_deg = max(self.pan_min_deg, min(self.start_pan_deg, self.pan_max_deg))
        self.last_target_angle_deg: Optional[float] = None
        self.last_target_time = self.get_clock().now()
        self.prev_scan_pan_deg: Optional[float] = None

        self.scan_sub = self.create_subscription(
            LaserScan, self.scan_topic, self.scan_cb, qos_profile_sensor_data)
        self.detect_pub = self.create_publisher(Bool, self.detect_topic, 10)
        self.actuate_pub = self.create_publisher(Bool, self.actuate_topic, 10)
        self.angle_pub = self.create_publisher(Float32, self.target_angle_topic, 10)
        self.range_pub = self.create_publisher(Float32, self.target_range_topic, 10)
        self.marker_pub = self.create_publisher(Marker, self.marker_topic, 10)
        self.pan_cmd_pub = self.create_publisher(Float32, self.pan_state_topic, 10)
        self.pan_desired_pub = self.create_publisher(Float32, self.pan_desired_topic, 10)
        self.servo_pub = None
        if self.enable_pan_tracking:
            self.servo_pub = self.create_publisher(
                Float32MultiArray, self.servo_topic, 10)
            self.create_timer(1.0 / self.tracker_publish_rate_hz, self._tracker_cb)

        self.get_logger().info(
            f"2D motion detector started: scan={self.scan_topic} "
            f"detect={self.detect_topic} actuate={self.actuate_topic} "
            f"angle={self.target_angle_topic} range={self.target_range_topic} "
            f"marker={self.marker_topic} pan_cmd={self.pan_state_topic} "
            f"pan_desired={self.pan_desired_topic} "
            f"sector=[{self.sector_min_deg:.1f}, {self.sector_max_deg:.1f}]deg "
            f"range=[{self.min_range_m:.2f}, {self.max_range_m:.2f}]m "
            f"delta={self.delta_range_m:.2f}m "
            f"min_cluster={self.min_cluster_beams} min_frames={self.min_motion_frames} "
            f"nearest_fallback={'on' if self.track_with_nearest_fallback else 'off'} "
            f"pan_tracking={'on' if self.enable_pan_tracking else 'off'} "
            f"track_require_detected={'on' if self.track_require_detected else 'off'} "
            f"pan_center={self.pan_center_deg:.1f}deg"
        )

    def _tracker_cb(self) -> None:
        if not self.enable_pan_tracking or self.servo_pub is None:
            return

        now = self.get_clock().now()
        age_sec = (now - self.last_target_time).nanoseconds / 1e9
        desired_pan_deg = self.pan_cmd_deg
        if (
            self.last_target_angle_deg is not None
            and age_sec <= self.target_timeout_sec
            and (not self.track_require_detected or self.last_detect_state)
        ):
            signed_target_deg = -self.last_target_angle_deg if self.invert_angle else self.last_target_angle_deg
            desired_pan_deg = self.pan_center_deg + signed_target_deg
            if desired_pan_deg > self.pan_max_deg:
                desired_pan_deg = self.pan_max_deg
            elif desired_pan_deg < self.pan_min_deg:
                desired_pan_deg = self.pan_min_deg
            error_deg = desired_pan_deg - self.pan_cmd_deg
            if abs(error_deg) > self.deadband_deg:
                delta = self.k_p * error_deg
                if delta > self.max_step_deg:
                    delta = self.max_step_deg
                elif delta < -self.max_step_deg:
                    delta = -self.max_step_deg
                self.pan_cmd_deg += delta
                if self.pan_cmd_deg > self.pan_max_deg:
                    self.pan_cmd_deg = self.pan_max_deg
                elif self.pan_cmd_deg < self.pan_min_deg:
                    self.pan_cmd_deg = self.pan_min_deg
            else:
                self.pan_cmd_deg = desired_pan_deg

        out = Float32MultiArray()
        out.data = [float(self.pan_cmd_deg), float(self.tilt_deg)]
        self.servo_pub.publish(out)
        self.pan_cmd_pub.publish(Float32(data=float(self.pan_cmd_deg)))
        self.pan_desired_pub.publish(Float32(data=float(desired_pan_deg)))

    def _beam_angle_deg(self, idx: int, angle_min: float, angle_inc: float) -> float:
        return (angle_min + idx * angle_inc) * 180.0 / math.pi

    def _is_valid_range(self, r: float) -> bool:
        return math.isfinite(r) and self.min_range_m <= r <= self.max_range_m

    def _find_moving_cluster(
        self,
        curr: List[float],
        prev: List[float],
        angle_min: float,
        angle_inc: float,
    ) -> Tuple[bool, int, Optional[float], Optional[float]]:
        run = 0
        max_run = 0
        best_start = -1
        best_end = -1
        run_start = -1
        for i, r_cur in enumerate(curr):
            ang = self._beam_angle_deg(i, angle_min, angle_inc)
            if ang < self.sector_min_deg or ang > self.sector_max_deg:
                if run > max_run:
                    max_run = run
                    best_start = run_start
                    best_end = i - 1
                run = 0
                run_start = -1
                continue

            r_prev = prev[i]
            if not self._is_valid_range(r_cur) or not self._is_valid_range(r_prev):
                if run > max_run:
                    max_run = run
                    best_start = run_start
                    best_end = i - 1
                run = 0
                run_start = -1
                continue

            if abs(r_cur - r_prev) >= self.delta_range_m:
                if run == 0:
                    run_start = i
                run += 1
            else:
                if run > max_run:
                    max_run = run
                    best_start = run_start
                    best_end = i - 1
                run = 0
                run_start = -1

        if run > max_run:
            max_run = run
            best_start = run_start
            best_end = len(curr) - 1

        if max_run < self.min_cluster_beams or best_start < 0 or best_end < best_start:
            return False, max_run, None, None

        center_idx = int((best_start + best_end) / 2)
        center_angle_rad = angle_min + center_idx * angle_inc
        center_range_m = float(curr[center_idx])
        return True, max_run, center_angle_rad, center_range_m

    def _find_nearest_target(
        self,
        curr: List[float],
        angle_min: float,
        angle_inc: float,
    ) -> Tuple[Optional[float], Optional[float]]:
        best_idx = -1
        best_range = float("inf")
        for i, r_cur in enumerate(curr):
            if not self._is_valid_range(r_cur):
                continue
            ang = self._beam_angle_deg(i, angle_min, angle_inc)
            if ang < self.sector_min_deg or ang > self.sector_max_deg:
                continue
            if r_cur < best_range:
                best_range = r_cur
                best_idx = i

        if best_idx < 0 or not math.isfinite(best_range):
            return None, None
        angle_rad = angle_min + best_idx * angle_inc
        return angle_rad, float(best_range)

    def _publish_marker(
        self,
        scan: LaserScan,
        detected: bool,
        angle_rad: Optional[float],
        range_m: Optional[float],
    ) -> None:
        if not self.publish_marker:
            return

        marker = Marker()
        marker.header = scan.header
        marker.ns = "moving_object"
        marker.id = 1

        if not detected or angle_rad is None or range_m is None:
            marker.action = Marker.DELETE
            self.marker_pub.publish(marker)
            return

        marker.action = Marker.ADD
        marker.type = Marker.SPHERE
        marker.pose.orientation.w = 1.0
        marker.pose.position = Point(
            x=range_m * math.cos(angle_rad),
            y=range_m * math.sin(angle_rad),
            z=0.0,
        )
        marker.scale.x = self.marker_size_m
        marker.scale.y = self.marker_size_m
        marker.scale.z = self.marker_size_m
        marker.color.r = 1.0
        marker.color.g = 0.1
        marker.color.b = 0.1
        marker.color.a = 0.95
        marker.lifetime.sec = 0
        marker.lifetime.nanosec = int(250e6)
        self.marker_pub.publish(marker)

    def scan_cb(self, msg: LaserScan) -> None:
        self.scan_count += 1
        now = self.get_clock().now()
        curr = list(msg.ranges)
        detected_now = False
        max_cluster = 0
        motion_angle_rad = None
        motion_range_m = None
        track_angle_rad = None
        track_range_m = None
        track_source = "none"
        pan_motion_block = False

        if self.prev_ranges is not None and len(self.prev_ranges) == len(curr):
            if (
                self.enable_pan_tracking
                and self.prev_scan_pan_deg is not None
                and abs(self.pan_cmd_deg - self.prev_scan_pan_deg) > self.max_pan_change_for_motion_deg
            ):
                pan_motion_block = True
            else:
                detected_now, max_cluster, motion_angle_rad, motion_range_m = self._find_moving_cluster(
                    curr, self.prev_ranges, msg.angle_min, msg.angle_increment)
            if motion_angle_rad is not None and motion_range_m is not None:
                track_angle_rad = motion_angle_rad
                track_range_m = motion_range_m
                track_source = "motion"

        if self.track_with_nearest_fallback and track_angle_rad is None:
            nearest_angle_rad, nearest_range_m = self._find_nearest_target(
                curr, msg.angle_min, msg.angle_increment)
            if nearest_angle_rad is not None and nearest_range_m is not None:
                track_angle_rad = nearest_angle_rad
                track_range_m = nearest_range_m
                track_source = "nearest"

        if detected_now:
            self.motion_streak += 1
        else:
            # Decay instead of hard reset to avoid one-frame dropouts.
            self.motion_streak = max(0, self.motion_streak - 1)

        detected = self.motion_streak >= self.min_motion_frames
        self.detect_pub.publish(Bool(data=detected))
        if detected and track_angle_rad is not None and track_range_m is not None:
            target_angle_deg = track_angle_rad * 180.0 / math.pi
            self.angle_pub.publish(Float32(data=target_angle_deg))
            self.range_pub.publish(Float32(data=track_range_m))
            if self.enable_pan_tracking:
                self.last_target_angle_deg = target_angle_deg
                self.last_target_time = now
            if self.debug_enabled:
                self.get_logger().info(
                    f"LOCK source={track_source} target={target_angle_deg:.2f}deg "
                    f"pan_cmd={self.pan_cmd_deg:.2f}deg invert={'on' if self.invert_angle else 'off'}"
                )
        self._publish_marker(
            msg,
            detected and track_angle_rad is not None and track_range_m is not None,
            track_angle_rad,
            track_range_m,
        )

        if detected and not self.last_detect_state:
            dt = (now - self.last_trigger_time).nanoseconds / 1e9
            if dt >= self.trigger_cooldown_sec:
                self.actuate_pub.publish(Bool(data=True))
                self.last_trigger_time = now

        self.last_detect_state = detected
        self.prev_ranges = curr
        self.prev_stamp = msg.header.stamp
        self.prev_scan_pan_deg = self.pan_cmd_deg

        if self.debug_enabled and (self.scan_count % self.debug_every_n == 0):
            self.get_logger().info(
                f"MOT scan#{self.scan_count} detected={'yes' if detected else 'no'} "
                f"streak={self.motion_streak} cluster={max_cluster} source={track_source} "
                f"pan_cmd={self.pan_cmd_deg:.2f} blocked={'yes' if pan_motion_block else 'no'}"
            )


def main() -> None:
    rclpy.init()
    node = ObjectMotionDetector2D()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()

