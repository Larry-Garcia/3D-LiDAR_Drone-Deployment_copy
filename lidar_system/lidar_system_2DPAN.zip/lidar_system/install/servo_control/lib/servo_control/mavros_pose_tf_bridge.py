#!/usr/bin/env python3
import rclpy
from geometry_msgs.msg import PoseStamped, TransformStamped
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from tf2_ros import TransformBroadcaster


class MavrosPoseTFBridge(Node):
    def __init__(self) -> None:
        super().__init__("mavros_pose_tf_bridge")

        self.pose_topic = self.declare_parameter("pose_topic", "/mavros/local_position/pose").value
        self.world_frame = self.declare_parameter("world_frame", "map").value
        self.base_frame = self.declare_parameter("base_frame", "base_link").value
        self.publish_rate_hz = float(self.declare_parameter("publish_rate_hz", 30.0).value)
        self.use_pose_stamp = bool(self.declare_parameter("use_pose_stamp", True).value)
        self.use_pose_orientation = bool(self.declare_parameter("use_pose_orientation", True).value)
        self.use_pose_position = bool(self.declare_parameter("use_pose_position", True).value)
        self.publish_identity_without_pose = bool(
            self.declare_parameter("publish_identity_without_pose", True).value
        )
        self.debug_enabled = bool(self.declare_parameter("debug_enabled", True).value)
        self.debug_every_n = int(self.declare_parameter("debug_every_n", 30).value)
        if self.publish_rate_hz <= 0.0:
            self.publish_rate_hz = 30.0
        if self.debug_every_n <= 0:
            self.debug_every_n = 30

        self.tf_broadcaster = TransformBroadcaster(self)
        self.pose_sub = self.create_subscription(
            PoseStamped, self.pose_topic, self.pose_cb, qos_profile_sensor_data)
        self.timer = self.create_timer(1.0 / self.publish_rate_hz, self.publish_tf)

        self.have_pose = False
        self.last_pose = None
        self.publish_count = 0

        self.get_logger().info(
            f"mavros_pose_tf_bridge started pose_topic={self.pose_topic} "
            f"{self.world_frame}->{self.base_frame} {self.publish_rate_hz:.1f}Hz"
        )

    def pose_cb(self, msg: PoseStamped) -> None:
        self.last_pose = msg
        self.have_pose = True

    def publish_tf(self) -> None:
        if not self.have_pose or self.last_pose is None:
            if not self.publish_identity_without_pose:
                return

            self.publish_count += 1
            tf_msg = TransformStamped()
            tf_msg.header.stamp = self.get_clock().now().to_msg()
            tf_msg.header.frame_id = self.world_frame
            tf_msg.child_frame_id = self.base_frame
            tf_msg.transform.translation.x = 0.0
            tf_msg.transform.translation.y = 0.0
            tf_msg.transform.translation.z = 0.0
            tf_msg.transform.rotation.x = 0.0
            tf_msg.transform.rotation.y = 0.0
            tf_msg.transform.rotation.z = 0.0
            tf_msg.transform.rotation.w = 1.0
            self.tf_broadcaster.sendTransform(tf_msg)

            if self.debug_enabled and (self.publish_count % self.debug_every_n == 0):
                self.get_logger().info(
                    f"BRIDGE tf#{self.publish_count} identity {self.world_frame}->{self.base_frame} "
                    "(waiting for MAVROS pose)"
                )
            return

        self.publish_count += 1
        tf_msg = TransformStamped()
        if self.use_pose_stamp and (self.last_pose.header.stamp.sec != 0 or self.last_pose.header.stamp.nanosec != 0):
            tf_msg.header.stamp = self.last_pose.header.stamp
        else:
            tf_msg.header.stamp = self.get_clock().now().to_msg()

        tf_msg.header.frame_id = self.world_frame
        tf_msg.child_frame_id = self.base_frame
        if self.use_pose_position:
            tf_msg.transform.translation.x = self.last_pose.pose.position.x
            tf_msg.transform.translation.y = self.last_pose.pose.position.y
            tf_msg.transform.translation.z = self.last_pose.pose.position.z
        else:
            tf_msg.transform.translation.x = 0.0
            tf_msg.transform.translation.y = 0.0
            tf_msg.transform.translation.z = 0.0

        if self.use_pose_orientation:
            tf_msg.transform.rotation = self.last_pose.pose.orientation
        else:
            tf_msg.transform.rotation.x = 0.0
            tf_msg.transform.rotation.y = 0.0
            tf_msg.transform.rotation.z = 0.0
            tf_msg.transform.rotation.w = 1.0

        self.tf_broadcaster.sendTransform(tf_msg)

        if self.debug_enabled and (self.publish_count % self.debug_every_n == 0):
            self.get_logger().info(
                f"BRIDGE tf#{self.publish_count} {self.world_frame}->{self.base_frame} "
                f"xyz=({tf_msg.transform.translation.x:.2f},"
                f"{tf_msg.transform.translation.y:.2f},"
                f"{tf_msg.transform.translation.z:.2f})"
            )


def main() -> None:
    rclpy.init()
    node = MavrosPoseTFBridge()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()

