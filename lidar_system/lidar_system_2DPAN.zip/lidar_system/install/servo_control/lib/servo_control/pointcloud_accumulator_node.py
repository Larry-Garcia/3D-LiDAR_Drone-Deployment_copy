#!/usr/bin/env python3
import math
from typing import Dict, List, Tuple

import rclpy
from rclpy.node import Node
from rclpy.qos import (
    DurabilityPolicy,
    HistoryPolicy,
    QoSProfile,
    ReliabilityPolicy,
    qos_profile_sensor_data,
)
from sensor_msgs.msg import PointCloud2
from std_msgs.msg import Float32MultiArray, Header

try:
    from sensor_msgs_py import point_cloud2
    HAVE_POINT_CLOUD2_HELPERS = True
except Exception:
    point_cloud2 = None
    HAVE_POINT_CLOUD2_HELPERS = False


class PointCloudAccumulatorNode(Node):
    @staticmethod
    def _as_bool(value) -> bool:
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            return value.strip().lower() in ("1", "true", "yes", "on")
        return bool(value)

    def __init__(self) -> None:
        super().__init__("pointcloud_accumulator_node")

        self.input_topic = self.declare_parameter(
            "input_topic", "/lidar_points").value
        self.output_topic = self.declare_parameter(
            "output_topic", "/lidar_points_accum").value
        self.servo_topic = self.declare_parameter(
            "servo_topic", "/servo_angles").value

        self.publish_rate_hz = float(
            self.declare_parameter("publish_rate_hz", 5.0).value)
        if self.publish_rate_hz <= 0.0:
            self.publish_rate_hz = 5.0

        self.publisher_reliable = self._as_bool(
            self.declare_parameter("publisher_reliable", True).value)
        self.output_frame = self.declare_parameter("output_frame", "").value
        self.passthrough_mode = self._as_bool(
            self.declare_parameter("passthrough_mode", True).value)
        self.use_servo_bins = self._as_bool(
            self.declare_parameter("use_servo_bins", True).value)
        self.require_recent_servo = self._as_bool(
            self.declare_parameter("require_recent_servo", True).value)
        self.max_servo_age_ms = float(
            self.declare_parameter("max_servo_age_ms", 250.0).value)

        self.pan_min_deg = float(
            self.declare_parameter("pan_min_deg", -90.0).value)
        self.pan_max_deg = float(
            self.declare_parameter("pan_max_deg", 90.0).value)
        self.pan_bin_deg = float(
            self.declare_parameter("pan_bin_deg", 3.0).value)
        if self.pan_bin_deg <= 0.0:
            self.pan_bin_deg = 3.0
        if self.pan_max_deg < self.pan_min_deg:
            tmp = self.pan_min_deg
            self.pan_min_deg = self.pan_max_deg
            self.pan_max_deg = tmp

        self.tilt_min_deg = float(
            self.declare_parameter("tilt_min_deg", -45.0).value)
        self.tilt_max_deg = float(
            self.declare_parameter("tilt_max_deg", 45.0).value)
        self.tilt_bin_deg = float(
            self.declare_parameter("tilt_bin_deg", 3.0).value)
        if self.tilt_bin_deg <= 0.0:
            self.tilt_bin_deg = 3.0
        if self.tilt_max_deg < self.tilt_min_deg:
            tmp = self.tilt_min_deg
            self.tilt_min_deg = self.tilt_max_deg
            self.tilt_max_deg = tmp

        self.bin_timeout_sec = float(
            self.declare_parameter("bin_timeout_sec", 4.0).value)
        if self.bin_timeout_sec <= 0.0:
            self.bin_timeout_sec = 4.0

        self.min_range_m = float(
            self.declare_parameter("min_range_m", 0.0).value)
        self.max_range_m = float(
            self.declare_parameter("max_range_m", 0.0).value)
        self.min_z_m = float(self.declare_parameter("min_z_m", -100.0).value)
        self.max_z_m = float(self.declare_parameter("max_z_m", 100.0).value)
        self.voxel_leaf_size_m = float(
            self.declare_parameter("voxel_leaf_size_m", 0.0).value)
        self.min_points_per_bin = int(
            self.declare_parameter("min_points_per_bin", 1).value)
        if self.min_points_per_bin < 0:
            self.min_points_per_bin = 0
        self.max_output_points = int(
            self.declare_parameter("max_output_points", 250000).value)
        if self.max_output_points <= 0:
            self.max_output_points = 250000

        self.debug_enabled = self._as_bool(
            self.declare_parameter("debug_enabled", True).value)
        self.debug_every_n_pubs = int(
            self.declare_parameter("debug_every_n_pubs", 10).value)
        if self.debug_every_n_pubs <= 0:
            self.debug_every_n_pubs = 10

        self.last_servo_pan_deg = 0.0
        self.last_servo_tilt_deg = 0.0
        self.last_servo_rx_time = None
        self.have_servo = False
        self.last_input_frame = ""

        if not HAVE_POINT_CLOUD2_HELPERS and not self.passthrough_mode:
            self.get_logger().warn(
                "sensor_msgs_py.point_cloud2 unavailable; forcing passthrough_mode=true"
            )
            self.passthrough_mode = True

        # Each bin holds: (stamp, frame_id, points_xyz32), keyed by (pan_bin, tilt_bin).
        self.bins: Dict[Tuple[int, int], Tuple[object, str,
                                   List[Tuple[float, float, float]]]] = {}
        self.input_count = 0
        self.pub_count = 0
        self.timer_count = 0
        self.drop_count = 0

        self.servo_sub = self.create_subscription(
            Float32MultiArray,
            self.servo_topic,
            self.servo_cb,
            qos_profile_sensor_data
        )
        self.cloud_sub = self.create_subscription(
            PointCloud2,
            self.input_topic,
            self.cloud_cb,
            qos_profile_sensor_data
        )
        if self.publisher_reliable:
            pub_qos = QoSProfile(
                history=HistoryPolicy.KEEP_LAST,
                depth=10,
                reliability=ReliabilityPolicy.RELIABLE,
                durability=DurabilityPolicy.VOLATILE,
            )
        else:
            pub_qos = qos_profile_sensor_data
        self.cloud_pub = self.create_publisher(
            PointCloud2, self.output_topic, pub_qos)
        self.timer = self.create_timer(
            1.0 / self.publish_rate_hz, self.publish_cb)

        self.get_logger().info(
            f"Accumulator started: {self.input_topic} -> {self.output_topic} "
            f"mode={'passthrough' if self.passthrough_mode else 'accumulate'} "
            f"qos={'reliable' if self.publisher_reliable else 'best_effort'} "
            f"bins={'on' if self.use_servo_bins else 'off'} "
            f"pan[{self.pan_min_deg:.1f}, {self.pan_max_deg:.1f}] "
            f"tilt[{self.tilt_min_deg:.1f}, {self.tilt_max_deg:.1f}] "
            f"bin=({self.pan_bin_deg:.1f},{self.tilt_bin_deg:.1f})deg "
            f"timeout={self.bin_timeout_sec:.1f}s"
        )

    def servo_cb(self, msg: Float32MultiArray) -> None:
        if len(msg.data) < 2:
            return
        self.last_servo_pan_deg = float(msg.data[0])
        self.last_servo_tilt_deg = float(msg.data[1])
        self.last_servo_rx_time = self.get_clock().now()
        self.have_servo = True

    def _compute_bin_idx(self) -> Tuple[int, int]:
        if not self.use_servo_bins:
            return (0, 0)
        pan = max(self.pan_min_deg, min(
            self.last_servo_pan_deg, self.pan_max_deg))
        tilt = max(self.tilt_min_deg, min(
            self.last_servo_tilt_deg, self.tilt_max_deg))
        pan_idx = int(round((pan - self.pan_min_deg) / self.pan_bin_deg))
        tilt_idx = int(round((tilt - self.tilt_min_deg) / self.tilt_bin_deg))
        return (pan_idx, tilt_idx)

    def _filter_points(self, msg: PointCloud2) -> List[Tuple[float, float, float]]:
        if point_cloud2 is None:
            return []
        pts: List[Tuple[float, float, float]] = []
        voxel_seen = set()
        use_voxel = self.voxel_leaf_size_m > 0.0

        for p in point_cloud2.read_points(msg, field_names=("x", "y", "z"), skip_nans=True):
            x = float(p[0])
            y = float(p[1])
            z = float(p[2])

            if z < self.min_z_m or z > self.max_z_m:
                continue

            r = math.sqrt(x * x + y * y + z * z)
            if r < self.min_range_m:
                continue
            if self.max_range_m > 0.0 and r > self.max_range_m:
                continue

            if use_voxel:
                vx = int(math.floor(x / self.voxel_leaf_size_m))
                vy = int(math.floor(y / self.voxel_leaf_size_m))
                vz = int(math.floor(z / self.voxel_leaf_size_m))
                key = (vx, vy, vz)
                if key in voxel_seen:
                    continue
                voxel_seen.add(key)

            pts.append((x, y, z))
        return pts

    def cloud_cb(self, msg: PointCloud2) -> None:
        self.input_count += 1
        now = self.get_clock().now()

        if self.passthrough_mode:
            self.cloud_pub.publish(msg)
            if self.debug_enabled and (self.input_count % self.debug_every_n_pubs == 0):
                self.get_logger().info(
                    f"ACC passthrough in={self.input_count} frame={msg.header.frame_id}"
                )
            return

        if self.require_recent_servo:
            if not self.have_servo or self.last_servo_rx_time is None:
                self.drop_count += 1
                return
            servo_age_ms = (now - self.last_servo_rx_time).nanoseconds / 1e6
            if servo_age_ms > self.max_servo_age_ms:
                self.drop_count += 1
                return

        try:
            filtered_points = self._filter_points(msg)
        except Exception as ex:
            self.get_logger().error(f"ACC cloud parse failed: {ex}")
            self.drop_count += 1
            return

        if len(filtered_points) < self.min_points_per_bin:
            self.drop_count += 1
            return

        bin_key = self._compute_bin_idx()
        self.bins[bin_key] = (now, msg.header.frame_id, filtered_points)
        self.last_input_frame = msg.header.frame_id

    def _prune_bins(self, now) -> None:
        stale = []
        for bin_key, (stamp, _, _) in self.bins.items():
            age_sec = (now - stamp).nanoseconds / 1e9
            if age_sec > self.bin_timeout_sec:
                stale.append(bin_key)
        for bin_key in stale:
            del self.bins[bin_key]

    def publish_cb(self) -> None:
        if self.passthrough_mode:
            return

        self.timer_count += 1
        self.pub_count += 1
        now = self.get_clock().now()
        self._prune_bins(now)

        if not self.bins:
            if self.debug_enabled and (self.timer_count % self.debug_every_n_pubs == 0):
                self.get_logger().warn(
                    f"ACC waiting: in={self.input_count} drops={self.drop_count} "
                    f"bins=0 have_servo={'yes' if self.have_servo else 'no'}"
                )
            return

        combined: List[Tuple[float, float, float]] = []
        for bin_key in sorted(self.bins.keys()):
            _, _, pts = self.bins[bin_key]
            combined.extend(pts)

        if not combined:
            return

        if len(combined) > self.max_output_points:
            step = int(math.ceil(len(combined) /
                       float(self.max_output_points)))
            combined = combined[::step]

        header = Header()
        header.stamp = now.to_msg()
        if self.output_frame:
            header.frame_id = self.output_frame
        elif self.last_input_frame:
            header.frame_id = self.last_input_frame
        else:
            # Fallback to map-like behavior if input frame isn't known yet.
            header.frame_id = "map"

        if point_cloud2 is None:
            self.get_logger().error(
                "ACC cannot publish accumulated cloud: sensor_msgs_py unavailable")
            return
        cloud_msg = point_cloud2.create_cloud_xyz32(header, combined)
        self.cloud_pub.publish(cloud_msg)

        if self.debug_enabled and (self.pub_count % self.debug_every_n_pubs == 0):
            self.get_logger().info(
                f"ACC pub#{self.pub_count} bins={len(self.bins)} "
                f"points={len(combined)} frame={header.frame_id} "
                f"pan={self.last_servo_pan_deg:.2f} "
                f"tilt={self.last_servo_tilt_deg:.2f}"
            )


def main() -> None:
    rclpy.init()
    node = PointCloudAccumulatorNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()

