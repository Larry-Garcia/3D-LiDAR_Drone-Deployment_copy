#!/usr/bin/env python3
from typing import Optional

import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool, Float32, Float32MultiArray


class ObjectPanTracker2D(Node):
    def __init__(self) -> None:
        super().__init__("object_pan_tracker_2d")

        self.target_angle_topic = self.declare_parameter(
            "target_angle_topic", "/moving_object_angle_deg").value
        self.detect_topic = self.declare_parameter(
            "detect_topic", "/moving_object_detected").value
        self.servo_topic = self.declare_parameter(
            "servo_topic", "/servo_angles").value

        self.publish_rate_hz = float(
            self.declare_parameter("publish_rate_hz", 12.0).value)
        if self.publish_rate_hz <= 0.0:
            self.publish_rate_hz = 12.0

        self.pan_min_deg = float(self.declare_parameter("pan_min_deg", -90.0).value)
        self.pan_max_deg = float(self.declare_parameter("pan_max_deg", 90.0).value)
        if self.pan_max_deg < self.pan_min_deg:
            self.pan_min_deg, self.pan_max_deg = self.pan_max_deg, self.pan_min_deg

        self.tilt_deg = float(self.declare_parameter("tilt_deg", 0.0).value)
        self.start_pan_deg = float(self.declare_parameter("start_pan_deg", 0.0).value)
        self.k_p = float(self.declare_parameter("k_p", 0.35).value)
        self.max_step_deg = float(self.declare_parameter("max_step_deg", 6.0).value)
        self.deadband_deg = float(self.declare_parameter("deadband_deg", 1.5).value)
        self.target_timeout_sec = float(self.declare_parameter("target_timeout_sec", 0.6).value)
        self.invert_angle = bool(self.declare_parameter("invert_angle", False).value)
        self.debug_enabled = bool(self.declare_parameter("debug_enabled", True).value)
        self.debug_every_n = int(self.declare_parameter("debug_every_n", 10).value)
        if self.debug_every_n < 1:
            self.debug_every_n = 10

        self.pan_cmd_deg = max(self.pan_min_deg, min(self.start_pan_deg, self.pan_max_deg))
        self.detected = False
        self.last_target_angle_deg: Optional[float] = None
        self.last_target_time = self.get_clock().now()
        self.tick = 0

        self.angle_sub = self.create_subscription(
            Float32, self.target_angle_topic, self.angle_cb, 10)
        self.detect_sub = self.create_subscription(
            Bool, self.detect_topic, self.detect_cb, 10)
        self.servo_pub = self.create_publisher(Float32MultiArray, self.servo_topic, 10)
        self.timer = self.create_timer(1.0 / self.publish_rate_hz, self.timer_cb)

        self.get_logger().info(
            f"2D pan tracker started: angle={self.target_angle_topic} "
            f"detect={self.detect_topic} -> {self.servo_topic} "
            f"pan[{self.pan_min_deg:.1f}, {self.pan_max_deg:.1f}] "
            f"tilt={self.tilt_deg:.1f} kp={self.k_p:.2f} "
            f"max_step={self.max_step_deg:.1f} deadband={self.deadband_deg:.1f} "
            f"timeout={self.target_timeout_sec:.2f}s "
            f"invert={'yes' if self.invert_angle else 'no'}"
        )

    def angle_cb(self, msg: Float32) -> None:
        self.last_target_angle_deg = float(msg.data)
        self.last_target_time = self.get_clock().now()

    def detect_cb(self, msg: Bool) -> None:
        self.detected = bool(msg.data)

    def timer_cb(self) -> None:
        self.tick += 1
        now = self.get_clock().now()
        age_sec = (now - self.last_target_time).nanoseconds / 1e9

        if self.detected and self.last_target_angle_deg is not None and age_sec <= self.target_timeout_sec:
            error_deg = -self.last_target_angle_deg if self.invert_angle else self.last_target_angle_deg
            if abs(error_deg) > self.deadband_deg:
                delta = self.k_p * error_deg
                if delta > self.max_step_deg:
                    delta = self.max_step_deg
                elif delta < -self.max_step_deg:
                    delta = -self.max_step_deg
                self.pan_cmd_deg += delta
                if self.pan_cmd_deg > self.pan_max_deg:
                    self.pan_cmd_deg = self.pan_max_deg
                elif self.pan_cmd_deg < self.pan_min_deg:
                    self.pan_cmd_deg = self.pan_min_deg

        out = Float32MultiArray()
        out.data = [float(self.pan_cmd_deg), float(self.tilt_deg)]
        self.servo_pub.publish(out)

        if self.debug_enabled and (self.tick % self.debug_every_n == 0):
            self.get_logger().info(
                f"TRK tick#{self.tick} pan={self.pan_cmd_deg:.2f} "
                f"tilt={self.tilt_deg:.2f} "
                f"detected={'yes' if self.detected else 'no'} "
                f"target={(self.last_target_angle_deg if self.last_target_angle_deg is not None else 0.0):.2f} "
                f"age={age_sec:.2f}s"
            )


def main() -> None:
    rclpy.init()
    node = ObjectPanTracker2D()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()

