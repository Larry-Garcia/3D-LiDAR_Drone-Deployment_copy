#include <cmath>
#include <cctype>
#include <chrono>
#include <string>
#include <vector>
#include "geometry_msgs/msg/transform_stamped.hpp"
#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/float32_multi_array.hpp"
#include "tf2/LinearMath/Quaternion.h"
#include "tf2_ros/transform_broadcaster.h"

class DynamicTFBroadcaster : public rclcpp::Node
{
public:
  DynamicTFBroadcaster()
  : Node("dynamic_tf_broadcaster"),
    current_pan_deg_(0.0),
    current_tilt_deg_(0.0)
  {
    base_frame_ = this->declare_parameter<std::string>("base_frame", "base_link");
    pan_frame_ = this->declare_parameter<std::string>("pan_frame", "pan_link");
    tilt_frame_ = this->declare_parameter<std::string>("tilt_frame", "tilt_link");
    laser_frame_ = this->declare_parameter<std::string>("laser_frame", "laser_frame");

    pan_origin_x_ = this->declare_parameter<double>("pan_origin_x", 0.0);
    pan_origin_y_ = this->declare_parameter<double>("pan_origin_y", 0.0);
    pan_origin_z_ = this->declare_parameter<double>("pan_origin_z", 0.0);

    tilt_origin_x_ = this->declare_parameter<double>("tilt_origin_x", 0.0);
    tilt_origin_y_ = this->declare_parameter<double>("tilt_origin_y", 0.0);
    tilt_origin_z_ = this->declare_parameter<double>("tilt_origin_z", 0.0);

    laser_origin_x_ = this->declare_parameter<double>("laser_origin_x", 0.0);
    laser_origin_y_ = this->declare_parameter<double>("laser_origin_y", 0.0);
    laser_origin_z_ = this->declare_parameter<double>("laser_origin_z", 0.0);

    pan_axis_ = normalize_axis(
      this->declare_parameter<std::string>("pan_axis", "z"),
      'z');
    tilt_axis_ = normalize_axis(
      this->declare_parameter<std::string>("tilt_axis", "y"),
      'y');

    pan_sign_ = this->declare_parameter<double>("pan_sign", 1.0);
    tilt_sign_ = this->declare_parameter<double>("tilt_sign", 1.0);
    pan_bias_deg_ = this->declare_parameter<double>("pan_bias_deg", 0.0);
    tilt_bias_deg_ = this->declare_parameter<double>("tilt_bias_deg", 0.0);

    laser_roll_deg_ = this->declare_parameter<double>("laser_roll_deg", 0.0);
    laser_pitch_deg_ = this->declare_parameter<double>("laser_pitch_deg", 0.0);
    laser_yaw_deg_ = this->declare_parameter<double>("laser_yaw_deg", 0.0);

    double publish_rate_hz = this->declare_parameter<double>("publish_rate_hz", 30.0);
    debug_enabled_ = this->declare_parameter<bool>("debug_enabled", false);
    debug_every_n_tf_ = this->declare_parameter<int>("debug_every_n_tf", 30);
    if (debug_every_n_tf_ <= 0) {
      debug_every_n_tf_ = 30;
    }
    if (publish_rate_hz <= 0.0) {
      RCLCPP_WARN(this->get_logger(), "publish_rate_hz <= 0, defaulting to 30Hz");
      publish_rate_hz = 30.0;
    }

    tf_broadcaster_ = std::make_shared<tf2_ros::TransformBroadcaster>(this);

    subscription_ = this->create_subscription<std_msgs::msg::Float32MultiArray>(
      "/servo_angles", 10,
      std::bind(&DynamicTFBroadcaster::angle_callback, this, std::placeholders::_1));

    timer_ = this->create_wall_timer(
      std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::duration<double>(1.0 / publish_rate_hz)),
      std::bind(&DynamicTFBroadcaster::broadcast_transform, this));

    RCLCPP_INFO(
      this->get_logger(),
      "Publishing TF chain %s->%s->%s->%s at %.1fHz "
      "(pan_axis=%c tilt_axis=%c pan_sign=%.1f tilt_sign=%.1f)",
      base_frame_.c_str(),
      pan_frame_.c_str(),
      tilt_frame_.c_str(),
      laser_frame_.c_str(),
      publish_rate_hz,
      pan_axis_,
      tilt_axis_,
      pan_sign_,
      tilt_sign_);
  }

private:
  static char normalize_axis(const std::string & axis, char fallback)
  {
    if (axis.empty()) {
      return fallback;
    }
    const char c = static_cast<char>(std::tolower(axis[0]));
    if (c == 'x' || c == 'y' || c == 'z') {
      return c;
    }
    return fallback;
  }

  static tf2::Quaternion quat_from_axis_angle(char axis, double angle_rad)
  {
    tf2::Quaternion q;
    if (axis == 'x') {
      q.setRPY(angle_rad, 0.0, 0.0);
    } else if (axis == 'y') {
      q.setRPY(0.0, angle_rad, 0.0);
    } else {
      q.setRPY(0.0, 0.0, angle_rad);
    }
    q.normalize();
    return q;
  }

  static geometry_msgs::msg::TransformStamped make_tf(
    const rclcpp::Time & stamp,
    const std::string & parent,
    const std::string & child,
    double tx,
    double ty,
    double tz,
    const tf2::Quaternion & q)
  {
    geometry_msgs::msg::TransformStamped t;
    t.header.stamp = stamp;
    t.header.frame_id = parent;
    t.child_frame_id = child;
    t.transform.translation.x = tx;
    t.transform.translation.y = ty;
    t.transform.translation.z = tz;
    t.transform.rotation.x = q.x();
    t.transform.rotation.y = q.y();
    t.transform.rotation.z = q.z();
    t.transform.rotation.w = q.w();
    return t;
  }

  void angle_callback(const std_msgs::msg::Float32MultiArray::SharedPtr msg)
  {
    if (msg->data.size() < 2) {
      RCLCPP_WARN(this->get_logger(), "Received servo_angles message with insufficient data");
      return;
    }
    current_pan_deg_ = msg->data[0];
    current_tilt_deg_ = msg->data[1];
    last_servo_msg_time_ = this->get_clock()->now();
    have_servo_msg_ = true;
  }

  void broadcast_transform()
  {
    ++tf_publish_count_;
    const rclcpp::Time stamp = this->get_clock()->now();
    const double pan_rad = (pan_sign_ * current_pan_deg_ + pan_bias_deg_) * M_PI / 180.0;
    const double tilt_rad = (tilt_sign_ * current_tilt_deg_ + tilt_bias_deg_) * M_PI / 180.0;

    const tf2::Quaternion q_pan = quat_from_axis_angle(pan_axis_, pan_rad);
    const tf2::Quaternion q_tilt = quat_from_axis_angle(tilt_axis_, tilt_rad);

    tf2::Quaternion q_laser_static;
    q_laser_static.setRPY(
      laser_roll_deg_ * M_PI / 180.0,
      laser_pitch_deg_ * M_PI / 180.0,
      laser_yaw_deg_ * M_PI / 180.0);
    q_laser_static.normalize();

    std::vector<geometry_msgs::msg::TransformStamped> tfs;
    tfs.reserve(3);
    tfs.push_back(make_tf(
      stamp,
      base_frame_,
      pan_frame_,
      pan_origin_x_,
      pan_origin_y_,
      pan_origin_z_,
      q_pan));
    tfs.push_back(make_tf(
      stamp,
      pan_frame_,
      tilt_frame_,
      tilt_origin_x_,
      tilt_origin_y_,
      tilt_origin_z_,
      q_tilt));
    tfs.push_back(make_tf(
      stamp,
      tilt_frame_,
      laser_frame_,
      laser_origin_x_,
      laser_origin_y_,
      laser_origin_z_,
      q_laser_static));

    tf_broadcaster_->sendTransform(tfs);

    if (debug_enabled_ && (tf_publish_count_ % static_cast<size_t>(debug_every_n_tf_) == 0)) {
      double servo_msg_age_ms = -1.0;
      if (have_servo_msg_) {
        servo_msg_age_ms = (this->get_clock()->now() - last_servo_msg_time_).seconds() * 1000.0;
      }
      RCLCPP_INFO(
        this->get_logger(),
        "DBG tf#%zu chain(%s->%s->%s->%s) pan=%.2fdeg tilt=%.2fdeg "
        "pan_rad=%.3f tilt_rad=%.3f servo_msg_age=%.1fms",
        tf_publish_count_,
        base_frame_.c_str(),
        pan_frame_.c_str(),
        tilt_frame_.c_str(),
        laser_frame_.c_str(),
        current_pan_deg_,
        current_tilt_deg_,
        pan_rad,
        tilt_rad,
        servo_msg_age_ms);
    }
  }

  std::shared_ptr<tf2_ros::TransformBroadcaster> tf_broadcaster_;
  rclcpp::Subscription<std_msgs::msg::Float32MultiArray>::SharedPtr subscription_;
  rclcpp::TimerBase::SharedPtr timer_;

  std::string base_frame_;
  std::string pan_frame_;
  std::string tilt_frame_;
  std::string laser_frame_;
  double pan_origin_x_;
  double pan_origin_y_;
  double pan_origin_z_;
  double tilt_origin_x_;
  double tilt_origin_y_;
  double tilt_origin_z_;
  double laser_origin_x_;
  double laser_origin_y_;
  double laser_origin_z_;
  char pan_axis_;
  char tilt_axis_;
  double pan_sign_;
  double tilt_sign_;
  double pan_bias_deg_;
  double tilt_bias_deg_;
  double laser_roll_deg_;
  double laser_pitch_deg_;
  double laser_yaw_deg_;
  double current_pan_deg_;
  double current_tilt_deg_;
  bool debug_enabled_{false};
  int debug_every_n_tf_{30};
  size_t tf_publish_count_{0};
  bool have_servo_msg_{false};
  rclcpp::Time last_servo_msg_time_{0, 0, RCL_ROS_TIME};
};

int main(int argc, char **argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<DynamicTFBroadcaster>());
  rclcpp::shutdown();
  return 0;
}
